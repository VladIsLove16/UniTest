﻿using Newtonsoft.Json;
using System.IO;
namespace TestAppOnWpf.FileSaveSystem
{
    class JsonSaveService : ISaveService
    {
        public void SaveData<T>(T data, string filePath = default)
        {
            if(filePath == default)
                filePath = typeof(T).ToString();
            var jsonData = JsonConvert.SerializeObject(data, Formatting.Indented);
            File.WriteAllText(filePath, jsonData);
        }

        public T LoadData<T>(string filePath = default)
        {
            if( filePath == default)
                filePath = typeof(T).ToString();
            if (!File.Exists(filePath))
                return default(T);

            var jsonData = File.ReadAllText(filePath);
            return JsonConvert.DeserializeObject<T>(jsonData);
        }
    }
}
