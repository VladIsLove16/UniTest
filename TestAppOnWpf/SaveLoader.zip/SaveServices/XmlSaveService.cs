﻿using System.IO;
using System.Xml.Serialization;
namespace TestAppOnWpf.FileSaveSystem
{
    class XmlSaveService : ISaveService 
    {
        public void SaveData<T>(T data, string filePath = default)
        {
            if (filePath == default)
                filePath = typeof(T).ToString();
            XmlSerializer serializer = new XmlSerializer(typeof(T));
            using (StreamWriter writer = new StreamWriter(filePath))
            {
                serializer.Serialize(writer, data);
            }
        }

        public T LoadData<T>(string filePath = default)
        {
            if (filePath == default)
                filePath = typeof(T).ToString();
            if (!File.Exists(filePath))
                return default(T);

            XmlSerializer serializer = new XmlSerializer(typeof(T));
            using (StreamReader reader = new StreamReader(filePath))
            {
                return (T)serializer.Deserialize(reader);
            }
        }
    }
   
}
