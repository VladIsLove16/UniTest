﻿namespace TestAppOnWpf.FileSaveSystem
{
    public  interface ISaveService
    {
        void SaveData<T>(T data, string filePath = default);
        T LoadData<T>(string filePath =default );
    } 

}
